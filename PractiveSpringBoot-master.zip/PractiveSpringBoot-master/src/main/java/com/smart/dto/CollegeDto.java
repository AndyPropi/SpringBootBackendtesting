package com.smart.dto;

public class CollegeDto {

	private Integer id;
	private String name;
	private String contactNumber;
	private String email;
	private String address;
	private String col1;
	private String col2;
	private String col3;
	private String col4;
	private String col5;

	private String col6Renamed;
	private String col7Renamed;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCol1() {
		return col1;
	}

	public void setCol1(String col1) {
		this.col1 = col1;
	}

	public String getCol2() {
		return col2;
	}

	public void setCol2(String col2) {
		this.col2 = col2;
	}

	public String getCol3() {
		return col3;
	}

	public void setCol3(String col3) {
		this.col3 = col3;
	}

	public String getCol4() {
		return col4;
	}

	public void setCol4(String col4) {
		this.col4 = col4;
	}

	public String getCol5() {
		return col5;
	}

	public void setCol5(String col5) {
		this.col5 = col5;
	}

	public String getCol6Renamed() {
		return col6Renamed;
	}

	public void setCol6Renamed(String col6Renamed) {
		this.col6Renamed = col6Renamed;
	}

	public String getCol7Renamed() {
		return col7Renamed;
	}

	public void setCol7Renamed(String col7Renamed) {
		this.col7Renamed = col7Renamed;
	}

	

}
