package com.smart;

import org.springframework.boot.SpringApplication; 
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartContactManager1Application {

	public static void main(String[] args) {
		SpringApplication.run(SmartContactManager1Application.class, args);
		System.err.println("project start");
	}

}
